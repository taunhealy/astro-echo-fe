import { cart } from './cart.ts';

export const server = {
	cart,
};
